
<?php
    session_start();
    $ses = $_SESSION['nom'];
        if ($ses == 'admin'){
            echo "
            <titre>
            <h1>La loutre joyeuse</h1>
            <h6>By MLVZ</h6>
            <img src='image/loutre1.jpg' alt= '' id='logo'/> 
            <a id='logo1' href='logout.php'><img src='image/compte.png' alt= '' id='logo1' /></a>
            <h5>Se déconnecter</h5>
        </titre>
        <onglet>
            <div class='onglets'>
            <a href='index.php'>Accueil</a>
            <a href='soin.php'>Nos soins</a>
            <a href='activite.php'>Activités</a>
            <a href='bientot.php'>Boutique</a>
            <a href='bientot.php'>Promotion</a>
            <a href='#contact'>Contact</a>
            <a href='insertion.php'>Ajouter</a>
            <a href='delete.php'>Supprimer</a>
            </div>
            </onglet>";
        } else {
            echo "
            <titre>
            <h1>La loutre joyeuse</h1>
            <h6>By MLVZ</h6>
            <img src='image/loutre1.jpg' alt= '' id='logo'/> 
            <a id='logo1' href='login.php'><img src='image/compte.png' alt= '' id='logo1' /></a>
            <h5>Vous êtes Admin ?</h5>
            </titre>
            <onglet>
            <div class='onglets'>
            <a href='index.php'>Accueil</a>
            <a href='soin.php'>Nos soins</a>
            <a href='activite.php'>Activités</a>
            <a href='bientot.php'>Boutique</a>
            <a href='bientot.php'>Promotion</a>
            <a href='#contact'>Contact</a>
            </div>
            </onglet>";
        }
?>
    
