<?php
session_start();
include("header.html");
include("content3.php");
include("form_log.html");
include("footer.html");

?>