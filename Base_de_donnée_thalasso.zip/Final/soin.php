<?php
session_start();
include("header.html");
include("content3.php");
?>

<h2> NOS SOINS </h2>

<div class="texteI">

    <div class="contenu">
        <div class="gauche">
            <h1> Massage aux pierre chaude</h1>
            <p> Profiter d'un bon massage aux pierre chaude entre les mains de nos expert. </p>
        </div>
        <div class="droite">
            <img src="image/slide1.jpg" alt="">
        </div>

    </div>
</div>


<div class="texteI2">

    <div class="contenu2">
        <div class="gauche2">
              <img src="image/slide2.jpg" alt="">
        </div>
        <div class="droite2">
            <h1> Espace zen et détente</h1>
            <p> Détendez-vous dans nos espcaes zen et détente avec un doux parfum de fleurs de cerisier. </p>
        </div>

    </div>
</div>

<div class="texteI">

    <div class="contenu">
        <div class="gauche">
            <h1> Piscines chauffées interieur/extérieur</h1>
            <p> Profiter de nos piscine pour vous reposer ou vous baignez seul ou en famille.</p>
        </div>
        <div class="droite">
            <img src="image/slide3.jpg" alt="">
        </div>

    </div>
</div>






    <footer>

        <h1>Qui sommes nous ?</h1>
        <div class="services">
            
            <div class="service">
                <h3>Le centre</h3>
                <p>Notre centre de thalassothérapie est basé dans la ville de Marseille, nous proposons de nombreuses activités et soins relaxant qui 
                vous aiderons à vous reposer et vous remettre en forme.</p>
            </div>

            <div class="service">
                <h3>Le personnel</h3>
                <p>L'entièreté de notre personnel qui vous accompagnera le long de votre séjour est compétant et diplômé d'Etat.</p>
            </div>

            <div class="service">
                <h3>Réservation</h3>
                <p>Vous pouvez réserver votre séjour via notre site internet ou alors en appelant par téléphone au numéro indiqué ci-dessous.</p>
            </div>

        </div>

        <b><p id="contact">Contact : 06 06 06 06 06 | &copy; 2021, La loutre joyeuse.</p>
    </footer>
</body>
</html>