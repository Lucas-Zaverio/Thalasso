<?php
session_start();
include("header.html");
include("content.php");
try {
    $user = 'mickael.vilayvanh';
    $pass = 'tAgeadai34';
    $cnx = new PDO("pgsql:host='sqletud.u-pem.fr'; dbname=mickael.vilayvanh_db",
    $user, $pass
    );
    echo "<table align='center'>\n";
    echo "\t\t\t<tr>
    \t<th>Prestation</th>
    \t<th>Année</th>
    \t<th>Saison</th>
    \t<th>Tarif</th>
    </tr>\n";
    $req = "SELECT * FROM contient";
    $res = $cnx->prepare($req);
    $res->execute();
    $res = $cnx->query($req);
    $res->setFetchMode(PDO::FETCH_ASSOC);
    foreach($res as $ligne){
        $cpt++;
        // Préserve uniquement les chiffre de 0 à 9 présents dans une chaine de caractères.
        $tab_annee = preg_replace('`[^0-9]`', '', $ligne['saison']);
        // Préserve uniquement les lettre de a à z dans la chaine
        $tab_saison = preg_replace('`[^a-z]`', '', $ligne['saison']);
        echo "\t\t\t<tr>\n";
        echo "\t\t\t\t<td>".$ligne['nom']."</td>\n";
        echo "\t\t\t\t<td>".$tab_annee."</td>\n";
        echo "\t\t\t\t<td>".$tab_saison."</td>\n";
        echo "\t\t\t\t<td>".$ligne['tarif']."€</td>\n";
        echo "\t\t\t</tr>\n";
    
    }
    echo "\t\t</table>\n";
}catch (PDOException $e){
    echo "ERREUR : La connexion a échouée";
}
?>
<p>Entrez les données à supprimer</p>
<form method="post" class="insertion" action="delete_valid.php">
    Nom de la prestation<br><input type="text" name="pres" size="12"><br><br>
    Période<br><input type="text" placeholder="Exemple: hiver2003" name="periode" size="12"><br><br>
    Tarif<br><input type="text" name="tarif" size="12"><br><br>
    <input type="submit" name = "connexion" value="Supprimer">
</form>

<?php
include("footer.html");
?>