<?php
include("header.html");
include("content3.php");
?>
<br>
<p>Insertion impossible</p>
<?php
include("footer.html");
?>