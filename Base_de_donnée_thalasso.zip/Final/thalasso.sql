DROP TABLE IF EXISTS prestation CASCADE;
DROP TABLE IF EXISTS soin CASCADE;
DROP TABLE IF EXISTS est_pourvu CASCADE;
DROP TABLE IF EXISTS critere CASCADE;
DROP TABLE IF EXISTS possede CASCADE;
DROP TABLE IF EXISTS etape CASCADE;
DROP TABLE IF EXISTS contient CASCADE;
DROP TABLE IF EXISTS periode CASCADE;
DROP TABLE IF EXISTS dates CASCADE;
DROP TABLE IF EXISTS dispose CASCADE;
DROP TABLE IF EXISTS logement CASCADE;
DROP TABLE IF EXISTS prestation_logement CASCADE;
DROP VIEW IF EXISTS prestation_tour_de_taille;
DROP VIEW IF EXISTS prix_cher;
DROP VIEW IF EXISTS prestation_prix_cher;

--- Création des tables

CREATE TABLE logement (
     id_logement varchar(3) PRIMARY KEY
);


CREATE TABLE periode (
    saison varchar(25) PRIMARY KEY,
    CONSTRAINT saisonPossible CHECK (
        saison LIKE 'hiver20%'
        OR saison LIKE 'ete20%'
        OR saison LIKE 'automne20%'
        OR saison LIKE 'printemps20%'
    )
);

CREATE TABLE prestation(
    nom varchar(25) PRIMARY KEY,
    type varchar (25),
    nb_jours int NOT NULL,
    CONSTRAINT jourspossible CHECK (
        nb_jours IN (2, 3, 4, 6)
    )
);

CREATE TABLE soin (
    code_soin char(5) PRIMARY KEY,
    objectif text,
    description text,
    effectif_max int,
    nom varchar(25),
    FOREIGN KEY (nom) REFERENCES prestation(nom)
    ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE etape (
    num_etape int PRIMARY KEY,
    description text,
    duree_minute int,
    CONSTRAINT num_etape_possible CHECK (num_etape > 0)
);


CREATE TABLE critere (
    code_critere varchar(6) PRIMARY KEY,
    libelle varchar(50)
);

CREATE TABLE prestation_logement (
    num_prestationL int,
    categorie varchar(25) NOT NULL,
    type varchar(25) NOT NULL,
    vue varchar(25) NOT NULL,
    PRIMARY KEY (num_prestationL),
    CONSTRAINT categoriePossible CHECK (categorie IN ('standard', 'confort', 'suite')),
    CONSTRAINT typePossible CHECK (type IN ('simple', 'double')),
    CONSTRAINT vuePossible CHECK (vue IN ('mer', 'jardin', 'rue'))
);

/*
CREATE TABLE dates (
    date_debut date PRIMARY KEY,
    date_fin date CHECK (date_fin BETWEEN date_debut + 1 AND date_debut + 90),
    saison varchar(25),
    FOREIGN KEY (saison) REFERENCES periode(saison)
    ON DELETE CASCADE ON UPDATE CASCADE
);
*/

CREATE TABLE est_pourvu (
    code_soin varchar(5),
    code_critere varchar(6),
    PRIMARY KEY (code_soin, code_critere),
    FOREIGN KEY (code_soin) REFERENCES soin(code_soin)
    ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (code_critere) REFERENCES critere(code_critere)
    ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE possede(
    code_soin char(5), 
    num_etape int CHECK (num_etape > 0),
    PRIMARY KEY (code_soin, num_etape),
    FOREIGN KEY (code_soin) REFERENCES soin(code_soin)
    ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (num_etape) REFERENCES etape(num_etape)
    ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE contient (
    nom varchar(25),
    saison varchar(25),
    tarif numeric(6,2) NOT NULL,
    PRIMARY KEY (nom, saison),
    FOREIGN KEY (nom) REFERENCES prestation(nom)
    ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (saison) REFERENCES periode(saison)
    ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE dispose (
    id_logement varchar(3),
    num_prestationL int,
    saison varchar(25),
    tarif numeric(6,2) NOT NULL,
    PRIMARY KEY (id_logement, num_prestationL, saison),
    FOREIGN KEY (id_logement) REFERENCES logement(id_logement)
    ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (num_prestationL) REFERENCES prestation_logement(num_prestationL)
    ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (saison) REFERENCES periode(saison)
    ON DELETE CASCADE ON UPDATE CASCADE
);

--- Insertions des vues

CREATE VIEW prestation_tour_de_taille AS (
    SELECT DISTINCT nom, type 
    FROM prestation NATURAL JOIN soin NATURAL JOIN est_pourvu NATURAL JOIN critere
    WHERE libelle = 'Tour de taille'
);

CREATE VIEW prestation_prix_cher AS (
    SELECT nom, type, saison, tarif
    FROM prestation NATURAL JOIN contient NATURAL JOIN periode
    ORDER BY tarif
    DESC
    LIMIT 5
);



--- Insertions des données dans la table


INSERT INTO prestation(nom, type, nb_jours)  
VALUES ('amincissement', 'cure', 6);
INSERT INTO prestation(nom, type, nb_jours)
VALUES ('bien-être', 'cure', 6);
INSERT INTO prestation(nom, type, nb_jours) 
VALUES ('beauté-fraîcheur', 'week-end', 3);
INSERT INTO prestation(nom, type, nb_jours)
VALUES ('détente', 'week-end', 2);


INSERT INTO soin(code_soin, objectif, description, nom) 
VALUES ('SAM01', 'libérer le corps de ses amas graisseux et de ses toxines, 
pour sculpter et affiner la silhouette.', 'Le soin se déroule en quatre étape : 
un massage, un bain, un gommage et un un repos.', 'amincissement');
INSERT INTO soin(code_soin, objectif, description, nom) 
VALUES ('BE42', 'Effectuer des soins relaxants afin d évacuer les tensions et la 
fatigue accumulée.', 'Le soin se déroule en 2 étape : un massage, un bain.', 'bien-être');
INSERT INTO soin(code_soin, objectif, description, nom) 
VALUES ('SBF13', 'Mettre le corps en contacte avec de l’eau à basse température pour 
améliorer la circulation du sang et raffermir la peau.', 'Le soin se déroule en quatre 
étape : un massage, un bain, un gommage et un un repos.', 'beauté-fraîcheur');
INSERT INTO soin(code_soin, objectif, description, nom) 
VALUES ('SD76', 'Se détendre à l’aide de soin reposant et 
d’activités physique', 'Le soin se déroule en quatre étape : un massage, du yoga, 
du cheval sur la plage, un bain', 'détente');

INSERT INTO critere(code_critere, libelle) 
VALUES ('SAM011',  'Tour de taille');
INSERT INTO critere(code_critere, libelle) 
VALUES ('SAM012',  'Tour de hanche');
INSERT INTO critere(code_critere, libelle) 
VALUES ('BE421',  'Tour de taille');
INSERT INTO critere(code_critere, libelle) 
VALUES ('BE422',  'Tour de hanche');
INSERT INTO critere(code_critere, libelle) 
VALUES ('BE423',  'Tour de cuisse');
INSERT INTO critere(code_critere, libelle) 
VALUES ('SBF131',  'Tour de taille');
INSERT INTO critere(code_critere, libelle) 
VALUES ('SBF132',  'Tour de hanche');
INSERT INTO critere(code_critere, libelle) 
VALUES ('SD761', 'Tour de taille');


INSERT INTO etape(num_etape, description, duree_minute) 
VALUES (1, 'Massage du dos',  20);
INSERT INTO etape(num_etape, description, duree_minute) 
VALUES (2, 'Repos avec masque au charbon',  60);
INSERT INTO etape(num_etape, description, duree_minute) 
VALUES (3, 'Repos sous lumière UV',  30);
INSERT INTO etape(num_etape, description, duree_minute) 
VALUES (4, 'Douche froide haute pression',  10);
INSERT INTO etape(num_etape, description, duree_minute) 
VALUES (5, 'Bain bouillonnant parfumé au fleur de cerisier',  15);
INSERT INTO etape(num_etape, description, duree_minute) 
VALUES (6, 'Gommage sous pluie marine',  15);
INSERT INTO etape(num_etape, description, duree_minute) 
VALUES (7, 'Yoga', 90);
INSERT INTO etape(num_etape, description, duree_minute) 
VALUES (8, 'Cheval sur la plage',  60);


INSERT INTO periode(saison) 
VALUES ('hiver2019');
INSERT INTO periode(saison) 
VALUES ('hiver2020');
INSERT INTO periode(saison) 
VALUES ('hiver2021');
INSERT INTO periode(saison) 
VALUES ('ete2019');
INSERT INTO periode(saison) 
VALUES ('ete2020');
INSERT INTO periode(saison) 
VALUES ('ete2021');
INSERT INTO periode(saison) 
VALUES ('automne2019');
INSERT INTO periode(saison) 
VALUES ('automne2020');
INSERT INTO periode(saison) 
VALUES ('automne2021');
INSERT INTO periode(saison) 
VALUES ('printemps2019');
INSERT INTO periode(saison) 
VALUES ('printemps2020');
INSERT INTO periode(saison) 
VALUES ('printemps2021');


INSERT INTO logement(id_logement) 
VALUES ('001');
INSERT INTO logement(id_logement) 
VALUES ('002');
INSERT INTO logement(id_logement) 
VALUES ('003');
INSERT INTO logement(id_logement) 
VALUES ('004');
INSERT INTO logement(id_logement) 
VALUES ('005');
INSERT INTO logement(id_logement) 
VALUES ('006');
INSERT INTO logement(id_logement) 
VALUES ('101');



INSERT INTO prestation_logement(num_prestationL, categorie, type, vue)
VALUES (1, 'standard', 'simple', 'rue');
INSERT INTO prestation_logement(num_prestationL, categorie, type, vue) 
VALUES (2, 'confort', 'simple', 'rue');
INSERT INTO prestation_logement(num_prestationL, categorie, type, vue) 
VALUES (3, 'suite', 'double', 'jardin');
INSERT INTO prestation_logement(num_prestationL, categorie, type, vue) 
VALUES (4, 'standard', 'simple', 'jardin');
INSERT INTO prestation_logement(num_prestationL, categorie, type, vue) 
VALUES (5, 'suite', 'double', 'mer');

/*
INSERT INTO dates(date_debut, date_fin, saison) 
VALUES ('2010-01-01', '2010-02-01', 'hiver2010');
*/

INSERT INTO est_pourvu(code_soin, code_critere) 
VALUES ('SAM01', 'SAM011');
INSERT INTO est_pourvu(code_soin, code_critere) 
VALUES ('SAM01', 'SAM012');
INSERT INTO est_pourvu(code_soin, code_critere) 
VALUES ('BE42', 'BE421');
INSERT INTO est_pourvu(code_soin, code_critere) 
VALUES ('BE42', 'BE422');
INSERT INTO est_pourvu(code_soin, code_critere) 
VALUES ('BE42', 'BE423');
INSERT INTO est_pourvu(code_soin, code_critere) 
VALUES ('SBF13', 'SBF131');
INSERT INTO est_pourvu(code_soin, code_critere) 
VALUES ('SBF13', 'SBF132');
INSERT INTO est_pourvu(code_soin, code_critere) 
VALUES ('SD76', 'SD761');


INSERT INTO possede(code_soin, num_etape) 
VALUES ('SAM01', 1);
INSERT INTO possede(code_soin, num_etape) 
VALUES ('SAM01', 5);
INSERT INTO possede(code_soin, num_etape) 
VALUES ('SAM01', 6);
INSERT INTO possede(code_soin, num_etape) 
VALUES ('SAM01', 2);
INSERT INTO possede(code_soin, num_etape) 
VALUES ('BE42', 1);
INSERT INTO possede(code_soin, num_etape) 
VALUES ('BE42', 5);
INSERT INTO possede(code_soin, num_etape) 
VALUES ('SBF13', 1);
INSERT INTO possede(code_soin, num_etape) 
VALUES ('SBF13', 5);
INSERT INTO possede(code_soin, num_etape) 
VALUES ('SBF13', 6);
INSERT INTO possede(code_soin, num_etape) 
VALUES ('SBF13', 3);
INSERT INTO possede(code_soin, num_etape) 
VALUES ('SD76', 1);
INSERT INTO possede(code_soin, num_etape) 
VALUES ('SD76', 7);
INSERT INTO possede(code_soin, num_etape) 
VALUES ('SD76', 8);
INSERT INTO possede(code_soin, num_etape) 
VALUES ('SD76', 5);


INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('001', 1, 'hiver2019', 180.00);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('001', 1, 'hiver2020',  170.00);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('001', 4, 'hiver2021',  250.00);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('002', 1, 'hiver2019', 180.00);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('101', 5, 'hiver2019', 469.99);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('101', 5, 'hiver2020', 459.99);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('101', 5, 'hiver2021', 479.99);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('101', 5, 'ete2019', 599.99);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('101', 5, 'ete2020', 569.99);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('101', 5, 'ete2021', 589.99);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('101', 5, 'automne2019', 500.00);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('101', 5, 'automne2020', 510.00);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('101', 5, 'automne2021', 499.99);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('003',3 , 'printemps2019', 489.99);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('003',3 , 'printemps2020', 509.99);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('003',3 , 'printemps2021', 499.99);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('004', 2, 'automne2019', 210.00);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('004', 2, 'automne2020', 205.00);
INSERT INTO dispose(id_logement, num_prestationL, saison, tarif) 
VALUES ('004', 2, 'automne2021', 220.00 );


INSERT INTO contient(nom, saison, tarif) 
VALUES ('amincissement', 'hiver2019', 400.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('amincissement', 'hiver2020', 380.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('amincissement', 'hiver2021', 350.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('amincissement', 'ete2019', 500.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('amincissement', 'ete2020', 485.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('amincissement', 'ete2021', 470.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('amincissement', 'automne2019', 430.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('amincissement', 'automne2020', 425.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('amincissement', 'automne2021', 410.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('amincissement', 'printemps2019', 475.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('amincissement', 'printemps2020', 470.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('amincissement', 'printemps2021', 460.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('bien-être', 'hiver2019', 395.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('bien-être', 'hiver2020', 390.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('bien-être', 'hiver2021', 380.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('bien-être', 'ete2019', 485.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('bien-être', 'ete2020', 480.00);
INSERT INTO contient(nom, saison, tarif)
VALUES ('bien-être', 'ete2021', 475.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('bien-être', 'automne2019', 425.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('bien-être', 'automne2020', 425.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('bien-être', 'automne2021', 410.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('bien-être', 'printemps2019', 465.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('bien-être', 'printemps2020', 455.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('bien-être', 'printemps2021', 450.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('beauté-fraîcheur', 'hiver2019', 200.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('beauté-fraîcheur', 'hiver2020', 185.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('beauté-fraîcheur', 'hiver2021', 185.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('beauté-fraîcheur', 'ete2019', 315.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('beauté-fraîcheur', 'ete2020', 300.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('beauté-fraîcheur', 'ete2021', 295.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('beauté-fraîcheur', 'automne2019', 240.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('beauté-fraîcheur', 'automne2020', 230.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('beauté-fraîcheur', 'automne2021', 225.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('beauté-fraîcheur', 'printemps2019', 300.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('beauté-fraîcheur', 'printemps2020', 270.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('beauté-fraîcheur', 'printemps2021', 270.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('détente', 'hiver2019', 150.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('détente', 'hiver2020', 145.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('détente', 'hiver2021', 140.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('détente', 'ete2019', 200.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('détente', 'ete2020', 185.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('détente', 'ete2021', 180.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('détente', 'automne2019', 160.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('détente', 'automne2020', 155.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('détente', 'automne2021', 155.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('détente', 'printemps2019', 190.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('détente', 'printemps2020', 180.00);
INSERT INTO contient(nom, saison, tarif) 
VALUES ('détente', 'printemps2021', 175.00);
