<?php
include("header.html");
include("content3.php");
?>
<br>
<p>Suppression impossible</p>
<?php
include("footer.html");
?>