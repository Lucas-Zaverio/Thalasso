<?php
include("header.html");
echo "\n";
?>
        <div class="vbar"></div>
        <a class="accueil" href="index.php">Accueil</a>
        <div id="titre">Centre de la loutre joyeuse</div>
        <div class="search">
            <?php
            include("form.php");
            echo "\n";
            ?>
        </div>
        <div class="centre">Aucun résultat trouvé.</div>
<?php
include("footer.html");
?>