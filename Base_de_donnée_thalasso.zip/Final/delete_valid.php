<?php
session_start();
include("header.html");
include("content3.php");

$user =  'mickael.vilayvanh';
$pass =  'tAgeadai34';
try {
    $cnx = new PDO("pgsql:host='sqletud.u-pem.fr'; dbname=mickael.vilayvanh_db",
    $user, $pass
    );
}
catch (PDOException $e) {
    echo "ERREUR : La connexion a échouée";
    echo "</br> $e";
}

$nom_pres = $_POST['pres'];
$periode = $_POST['periode'];
$tarif = $_POST['tarif'];

if (isset($_POST['pres']) && isset($_POST['periode']) && isset($_POST['tarif'])){
    header("Location: no_insert.php");
    die();
}

$req_prd = "SELECT * FROM contient";
$res = $cnx->query($req_prd);
$res->setFetchMode(PDO::FETCH_ASSOC);
foreach($res as $ligne){
    if ($ligne['nom'] == $nom_pres && $ligne['saison'] == $periode ){
        if(isset($_POST['pres'])
        && isset($_POST['periode'])
        && isset($_POST['tarif'])){
            try{
                $req_delete = "DELETE FROM contient
                                WHERE nom = '".$nom_pres."' 
                                AND saison = '".$periode."' AND tarif = ".$tarif;
                if ($req_delete == 0){
                    header("Location: no_insert.php");
                    die();
                }

                $req_delete = "DELETE FROM prestation
                                WHERE nom = '".$nom_pres;
                $cnx->exec($req_delete);

                $req_delete = "DELETE FROM periode
                            WHERE saison = '".$periode;
                $cnx->exec($req_delete);

                
                $cnx->exec($req_delete);
            } catch (PDOException $e){
                header("Location: no_insert.php");
                die();
            }
        } else {
            header("Location: no_insert.php");
            die();
        }
    } else {
        header("Location: no_insert.php");
        die();
    }
}
$res->closeCursor();
?>
<br>
<p>Insertion effectuée.</p>
<br>
<?php
include("footer.html");
?>