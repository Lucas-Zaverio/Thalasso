<?php
session_start();
include("header.html");
echo "\n";
include("content.php");
echo "\n";
include("content2.php");
echo "\n";
include("footer.html");
?>
