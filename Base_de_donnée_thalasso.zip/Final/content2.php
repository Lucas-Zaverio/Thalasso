<section class="main" id="produits">
<soins>
    <h1> NOS SOINS </h1>
</soins>
<div class="slider">
    <a href='soin.php'>
        <div class="slides">
            <div class="slide"><img src="image/slide1.jpg" alt=""/></div>
            <div class="slide"><img src="image/slide2.jpg" alt=""/></div>
            <div class="slide"><img src="image/slide3.jpg" alt=""/></div>
        </div>
    </a>
</div>
</section>

<section class="main" id="activite">
<activite>
    <h1> NOS ACTIVITES </h1>
</activite>
<div class="slider">
    <a href='activite.php'>
        <div class="slides">
            <div class="slide"><img src="image/slide4.png" alt=""/></div>
            <div class="slide"><img src="image/slide5.png" alt=""/></div>
            <div class="slide"><img src="image/slide6.png" alt=""/></div>
        </div>
    </a>
</div>
</section>