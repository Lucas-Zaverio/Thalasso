<?php
session_start();
include("header.html");
include("content3.php");
?>

<form method="post" class="insertion" action="insert_valid.php">
    Nom de la prestation<br><input type="text" name="pres" size="12"><br><br>
    Période<br><input type="text" placeholder="Exemple: hiver2003" name="periode" size="12"><br><br>
    Tarif<br><input type="text" name="tarif" size="12"><br><br>
    <input type="radio" name="type" id="cure" value="cure">
    <label for="cure">Cure</label><br>
    <input type="radio" name="type" id="we" value="week-end">
    <label for="we">Week-End</label>
    <input type="radio" name="jour" id="2jour" value="2">
    <label for="2jour">2 jours</label>
    <input type="radio" name="jour" id="3jour" value="3">
    <label for="3jour">3 jours</label>
    <input type="radio" name="jour" id="4jour" value="4">
    <label for="4jour">4 jours</label>
    <?php
        $sel = $_POST['type'];
        if (isset($sel) && $sel == 'we'){
            echo "<select name='jour'>\n
            <option value='2'>2</option>\n
            <option value='3'>3</option>\n
            <option value='4'>4</option>\n
            </select>";
        }
    ?>
    
    <input type="submit" name = "connexion" value="Ajouter">
</form>
<?php
include("footer.html");
?>
