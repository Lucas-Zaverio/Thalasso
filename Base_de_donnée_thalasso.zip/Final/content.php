<body>
    <?php
        session_start();
        include("content3.php");
        include("form.php");
    ?>
    <header>
        <h1>Centre de thalassothérapie</h1>
        <h4>Créateur de bien-être</h4>
    </header>