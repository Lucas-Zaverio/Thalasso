<?php
    session_start();
    $user = 'mickael.vilayvanh';
    $pass = 'tAgeadai34';
    try {
        $cnx = new PDO("pgsql:host='sqletud.u-pem.fr'; dbname=mickael.vilayvanh_db",
        $user, $pass
        );
        $id = $_POST['identifiant'];
        $pw = $_POST['password'];
        if($pw == 'ADMIN' && $id == 'ADMIN'){
            $_SESSION['nom'] = 'admin';
            header("Location: index.php");
            die();
        }
        header("Location: no_result_log.php");
        die();  
    }
    
    catch (PDOException $e) {
        echo "ERREUR : La connexion a échouée";
        echo "</br> $e";
    }
    include("footer.html");
?>