<?php
include("header.html");
include("content3.php");
?>

<h2>Bientôt...</h2>

    <footer>

        <h1>Qui sommes nous ?</h1>
        <div class="services">
            
            <div class="service">
                <h3>Le centre</h3>
                <p>Notre centre de thalassothérapie est basé dans la ville de Marseille, nous proposons de nombreuses activités et soins relaxant qui 
                vous aiderons à vous reposer et vous remettre en forme.</p>
            </div>

            <div class="service">
                <h3>Le personnel</h3>
                <p>L'entièreté de notre personnel qui vous accompagnera le long de votre séjour est compétant et diplômé d'Etat.</p>
            </div>

            <div class="service">
                <h3>Réservation</h3>
                <p>Vous pouvez réserver votre séjour via notre site internet ou alors en appelant par téléphone au numéro indiqué ci-dessous.</p>
            </div>

        </div>

        <b><p id="contact">Contact : 06 06 06 06 06 | &copy; 2021, La loutre joyeuse.</p>
    </footer>
</body>
</html>