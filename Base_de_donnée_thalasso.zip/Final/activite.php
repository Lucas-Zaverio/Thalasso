<?php
session_start();
include("header.html");
include("content3.php");
?>

<h2> NOS ACTIVITES </h2>

<div class="texteI">

    <div class="contenu">
        <div class="gauche">
            <h1> Yoga</h1>
            <p> Participez à nos cours de Yoga seul ou collectif pour vous recentrez sur vous-même. </p>
        </div>
        <div class="droite">
            <img src="image/slide4.jpg" alt="">
        </div>

    </div>
</div>


<div class="texteI2">

    <div class="contenu2">
        <div class="gauche2">
              <img src="image/slide5.png" alt="">
        </div>
        <div class="droite2">
            <h1> Equitation</h1>
            <p> Nos chevaux n'attendent que vous pour êtres chevauchez alors n'hésitez plus. </p>
        </div>

    </div>
</div>

<div class="texteI">

    <div class="contenu">
        <div class="gauche">
            <h1> Course à pieds</h1>
            <p> Participez à nos sessions de course à pieds en groupe, un moment de convivialité. </p>
        </div>
        <div class="droite">
            <img src="image/slide6.png" alt="">
        </div>

    </div>
</div>






    <footer>

        <h1>Qui sommes nous ?</h1>
        <div class="services">
            
            <div class="service">
                <h3>Le centre</h3>
                <p>Notre centre de thalassothérapie est basé dans la ville de Marseille, nous proposons de nombreuses activités et soins relaxant qui 
                vous aiderons à vous reposer et vous remettre en forme.</p>
            </div>

            <div class="service">
                <h3>Le personnel</h3>
                <p>L'entièreté de notre personnel qui vous accompagnera le long de votre séjour est compétant et diplômé d'Etat.</p>
            </div>

            <div class="service">
                <h3>Réservation</h3>
                <p>Vous pouvez réserver votre séjour via notre site internet ou alors en appelant par téléphone au numéro indiqué ci-dessous.</p>
            </div>

        </div>

        <b><p id="contact">Contact : 06 06 06 06 06 | &copy; 2021, La loutre joyeuse.</p>
    </footer>
</body>
</html>