<?php
session_start();
include("header.html");
include("content3.php");

$user = 'mickael.vilayvanh';
$pass = 'tAgeadai34';
try {
    $cnx = new PDO("pgsql:host='sqletud.u-pem.fr'; dbname=mickael.vilayvanh_db",
    $user, $pass
    );
}
catch (PDOException $e) {
    echo "ERREUR : La connexion a échouée";
    echo "</br> $e";
}

$nom_pres = $_POST['pres'];
$type = $_POST['type'];
$jour = 6;
$periode = $_POST['periode'];
$tarif = $_POST['tarif'];
if (isset($type) && $type == 'week-end'){
    if (isset($_POST['jour'])){
        $jour = intval($_POST['jour']);
    } else {
        header("Location: no_insert.php");
        die();
    }
}

$req_prest = "SELECT nom FROM prestation";
$res = $cnx->query($req_prest);
$res->setFetchMode(PDO::FETCH_ASSOC);

foreach($res as $nom){
    if ($nom['nom'] == $nom_pres){
        header("Location: no_insert.php");
        die();
    }
}

$res->closeCursor();

$req_prd = "SELECT saison FROM periode";
$res = $cnx->query($req_prd);
$res->setFetchMode(PDO::FETCH_ASSOC);

foreach($res as $nom){
    if ($nom['saison'] == $periode){
        header("Location: no_insert.php");
        die();
    }
}

$res->closeCursor();

if(isset($_POST['pres']) && isset($_POST['type']) && isset($_POST['jour']) && isset($_POST['periode'])
 && isset($_POST['tarif'])){
    try{
        $req_insert = "INSERT INTO prestation
                        VALUES ('".$nom_pres."','".$type."',".$jour.")";
        $cnx->exec($req_insert);

        $req_insert = "INSERT INTO periode
                        VALUES ('".$periode."')";
        $cnx->exec($req_insert);

        $req_insert = "INSERT INTO contient
                        VALUES ('".$nom_pres."','".$periode."',".$tarif.")";
        $cnx->exec($req_insert);
    } catch (PDOException $e){
        header("Location: no_insert.php");
        die();
    }
} else {
    header("Location: no_insert.php");
    die();
}
?>
<br>
<p>Insertion effectuée.</p>
<br>
<?php
include("footer.html");
?>