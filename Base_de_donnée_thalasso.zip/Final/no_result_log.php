<?php
session_start();
include("header.html");
include("content3.php");
include("form.php");
echo "<br><br><br>";
include("form_log.html");
?>
<br>
<div class="centre">Identifiant ou mot de passe incorrect</div>
<?php
include("footer.html");
?>